import asyncio
import logging
import os
import json
import csv
import time

from maker import MakePdfDefault, MakePdfBlue, MakePdfBlueHor
from pyroaddon import listen
from pyrogram import Client, filters
from pyrogram.handlers import MessageHandler
from pyrogram.types import (Message,
                            ReplyKeyboardMarkup,
                            KeyboardButton, InputMediaPhoto,
                            ReplyKeyboardRemove, WebAppInfo)
from pyrogram.enums import ChatAction, ParseMode

logging.basicConfig(level=logging.INFO,
                    filename='logs.log',
                    filemode='w',
                    format='%(asctime)s %(levelname)s %(message)s')

usersA = []
langs = {
	312312: 'ru'
}

API_ID = # API ID
API_HASH = # API HASH
BOT_TOKEN = '6360370853:AAEg6Xo9qdal-RPaI9agaAT7h6PzDubNths'

bot = Client('CV MakerBot',
             api_id=API_ID,
             api_hash=API_HASH,
             bot_token=BOT_TOKEN)

users_dict = {}


class User:
	def __init__(self, user_id, nick, username, started_time):
		self.user_id = user_id
		self.nick = nick
		self.username = username
		self.started_time = started_time
		self.language = 'None'
		self.status = 'None'
		self.cv_started_time = None
		self.cv_form = 0
		self.age = 0
		self.rate = 0


async def getPhoto(chat_id):
	if langs[chat_id] == 'uz':
		while True:
			photo = await bot.ask(
				chat_id,
				'Rezyume uchun rasm tashlang yoki tugmani bosing',
				reply_markup=ReplyKeyboardMarkup([[KeyboardButton('Rasmsiz qilish')]],
				                                 resize_keyboard=True, is_persistent=True, one_time_keyboard=True))
			photo: Message
			if photo.photo:
				photoSRC = await bot.download_media(photo)
				break
			elif photo.text == 'Rasmsiz qilish':
				photoSRC = ''
				break
		return photoSRC
	else:
		while True:
			photo = await bot.ask(
				chat_id,
				'Отправьте фото к резюме или нажмите на кнопку',
				reply_markup=ReplyKeyboardMarkup([[KeyboardButton('Резюме без фото')]],
				                                 resize_keyboard=True, is_persistent=True, one_time_keyboard=True))
			photo: Message
			if photo.photo:
				photoSRC = await bot.download_media(photo)
				break
			elif photo.text == 'Резюме без фото':
				photoSRC = ''
				break
		return photoSRC


async def cvForm(chat_id):
	while True:
		await bot.send_media_group(chat_id, [
			InputMediaPhoto('cvs/first.jpg', caption='1-шаблон'),
			InputMediaPhoto('cvs/second.jpg', caption='2-шаблон'),
			InputMediaPhoto('cvs/third.jpg', caption='3-шаблон')])
		form = await bot.ask(
			chat_id, 'Rezyume uchun shablon tanlang\nВыберите шаблон для резюме',
			reply_markup=ReplyKeyboardMarkup([[
				KeyboardButton('1-шаблон'),
				KeyboardButton('2-шаблон'),
				KeyboardButton('3-шаблон')
			]], resize_keyboard=True, is_persistent=True, one_time_keyboard=True))
		form: Message
		if form.text in ['1-шаблон', '2-шаблон', '3-шаблон']:
			if form.text == '1-шаблон':
				return 1
			elif form.text == '2-шаблон':
				return 2
			else:
				return 3
		else:
			continue


async def changeLang(chat_id):
	user = users_dict[chat_id]
	markupLang = ReplyKeyboardMarkup([[
		KeyboardButton('🇺🇿 Ozbek tili'),
		KeyboardButton('🇷🇺 Русский язык')]],
		resize_keyboard=True, is_persistent=True)
	
	while True:
		lang = await bot.ask(chat_id, 'Выберите язык\nTilni tanlang', reply_markup=markupLang)
		lang: Message
		if lang.text == '🇷🇺 Русский язык':
			langs.update({chat_id: 'ru'})
			user.language = 'ru'
			users_dict.update({chat_id: user})
			break
		elif lang.text == '🇺🇿 Ozbek tili':
			langs.update({chat_id: 'uz'})
			user.language = 'uz'
			users_dict.update({chat_id: user})
			break
		else:
			continue


async def markupSender(chat_id, lang):
	user = users_dict[chat_id]
	if lang == 'ru':
		webApp = WebAppInfo(url='https://cvbox.uz/cvbot/makerRu.php')
	else:
		webApp = WebAppInfo(url='https://cvbox.uz/cvbot/makerUz.php')
	mainMarkupRu = ReplyKeyboardMarkup([[
		KeyboardButton('🔺Главное меню'), KeyboardButton('💼 Создать резюме', web_app=webApp),
		KeyboardButton('Образцы резюме')], [KeyboardButton('О нас'), KeyboardButton('🇷🇺Поменять язык')]],
		resize_keyboard=True,
		is_persistent=True)
	mainMarkupUz = ReplyKeyboardMarkup([[
		KeyboardButton('🔺Asosiy menyu'), KeyboardButton('💼 Rezyume yaratish', web_app=webApp),
		KeyboardButton('Rezyume namunalari')], [KeyboardButton('Biz haqimizda'), KeyboardButton('🇺🇿Tilni ozgartirish')]],
		resize_keyboard=True,
		is_persistent=True)
	user.cv_started_time = (time.time() + 2)
	users_dict.update({chat_id: user})
	if lang == 'ru':
		await bot.send_message(chat_id, '⌨️ Выберите действие из списка:', reply_markup=mainMarkupRu)
	elif lang == 'uz':
		await bot.send_message(chat_id, '⌨️ Royxatdan amalni tanlang:', reply_markup=mainMarkupUz)


async def changeLanguage(bot: Client, mess: Message):
	chat_id = mess.chat.id
	await changeLang(chat_id)
	await markupSender(chat_id, langs[chat_id])


async def getStart(bot: Client, mess: Message):
	chat_id = mess.chat.id
	if mess.from_user.username:
		username = mess.from_user.username
	else:
		username = 'None'
	user = User(user_id=chat_id,
	            nick=mess.from_user.first_name,
	            username=username,
	            started_time=str(mess.date))
	users_dict[chat_id] = user
	
	with open('starts.csv', 'a') as file:
		writer = csv.writer(file, delimiter=',')
		
		writer.writerow([
			chat_id,
			mess.from_user.first_name,
			f'@{username}',
			str(mess.date)])
	
	markupD = ReplyKeyboardRemove()
	if chat_id not in usersA:
		text = ("🇺🇿 Assalomu alaykum,\n "
		        "CVBox.uz\"ga Xush kelibsiz!\n"
		        "🇷🇺 Здравствуйте,\n"
		        "Добро пожаловать в \"CVBox.uz'!")
		await bot.send_message(chat_id=chat_id, text=text, reply_to_message_id=mess.id, reply_markup=markupD)
		await asyncio.sleep(1.2)
		
		await changeLang(chat_id)
		
		usersA.append(chat_id)
		while True:
			if langs[chat_id] == 'ru':
				statusButtons = ReplyKeyboardMarkup(
					[[
						KeyboardButton('👨‍🎓Студент'),
						KeyboardButton('🕵️‍♂️Безработный')
					], [
						KeyboardButton('👨‍💼Рабочий'),
						KeyboardButton('👨‍💻Фрилансер')
					]],
					resize_keyboard=True, is_persistent=True
				)
				status = await bot.ask(chat_id, '🛠️Выберите ваш статус:', reply_markup=statusButtons)
				status: Message
				if status.text in ['👨‍🎓Студент', 'Безработный', '👨‍💼Рабочий', '👨‍💻Фрилансер']:
					user.status = status.text
					users_dict.update({chat_id: user})
					break
				else:
					continue
			elif langs[chat_id] == 'uz':
				statusButtons = ReplyKeyboardMarkup(
					[[
						KeyboardButton('👨‍🎓Talaba'),
						KeyboardButton('🕵️‍♂️Ish qidiruvchi'),
					], [
						KeyboardButton('👨‍💼Xodim'),
						KeyboardButton('👨‍💻Frilanser')
					]],
					resize_keyboard=True, is_persistent=True
				)
				status = await bot.ask(chat_id, '🛠️ Asosiy bandligingizni tanlang 👇:', reply_markup=statusButtons)
				status: Message
				if status.text in ['👨‍🎓Talaba', '🕵️‍♂️Ish qidiruvchi', '👨‍💼Xodim', '👨‍💻Frilanser']:
					user.status = status.text
					users_dict.update({chat_id: user})
					break
				else:
					continue
	
	if langs[chat_id] == 'ru':
		await markupSender(chat_id, 'ru')
	elif langs[chat_id] == 'uz':
		await markupSender(chat_id, 'uz')


async def aboutUs(bot: Client, mess: Message):
	chat_id = mess.chat.id
	text = ""
	if langs[chat_id] == 'uz':
		text = """Bizning servisimiz orqali siz Shaxsiy Rezyume yaratishingiz mumkin.
- Rezyume korinishini tanlang.
- Malumotlarni kiriting.
- Rezyumeni yuklab oling.
✅ Tez, Oson va Ishonchli
  """
	elif langs[chat_id] == 'ru':
		text = """С помощью нашего сервиса вы можете создать собственное резюме.
- Выберите вид резюме.
- Введите данные.
- Загрузите резюме.
✅ Быстро и легко
"""
	await bot.send_message(chat_id, text)


async def sampleCVs(bot: Client, mess: Message):
	chat_id = mess.chat.id
	await bot.send_message(chat_id,
	                       '<a href="https://telegra.ph/SHablony-04-09-2">Шаблоны</a>',
	                       parse_mode=ParseMode.HTML)


async def sampleCVMaker(bot: Client, mess: Message):
	chat_id = mess.chat.id
	langs[chat_id] = 'uz'
	langToCv: Message = await bot.ask(
		chat_id,
		'Til: ',
		reply_markup=ReplyKeyboardMarkup([[KeyboardButton('uz'), KeyboardButton('ru')]],
		                                 is_persistent=True,
		                                 resize_keyboard=True,
		                                 one_time_keyboard=True))
	data = {
		"name": "Alisher",
		"surname": "Eshqobilov",
		"phone": "+923152904968",
		"email": "emailToPass@gmail.com",
		"age": "30",
		"city": "Toshkent",
		"work_companies": ["Uzunbuloq suv tozalash inshooti"],
		"work_roles": ["Yetakchi mutaxassis"],
		"work_dates_from": ["2021"],
		"work_dates_to": ["2022"],
		"edu_unis": ["Jizzay iqtisodiyot instituti", "Toshkent Moliya instituti"],
		"edu_levels": ["Bachelor", "master"],
		"edu_directs": ["Quruvchi muhandisi", "Moliya va sarmoya"],
		"edu_dates_from": ["2018", "2022"],
		"edu_dates_to": ["2022", "2024"],
		"langs": ["Rus tili", "Ingliz tili"],
		"lang_levels": ["middle", "middle"],
		"skills": ["MS Office", "Photoshop"],
		"skill_levels": ["middle", "basic"],
		"certifications": ["IELTS B2", "Udemy DS", "Skypro ML"],
		"characteristics": ["Adaptive", "Sabrlilik"],
		"language": langToCv.text,
	}
	
	await bot.send_chat_action(chat_id, ChatAction.UPLOAD_DOCUMENT)
	name = data['name']
	surname = data['surname']
	phoneNumber = data['phone']
	email = data['email']
	age = data['age']
	city = data['city']
	workCompanies = data['work_companies']
	workRoles = data['work_roles']
	workDatesFrom = data['work_dates_from']
	workDatesTo = data['work_dates_to']
	educationUnis = data['edu_unis']
	educationLevels = data['edu_levels']
	educationDirections = data['edu_directs']
	educationDatesFrom = data['edu_dates_from']
	educationDatesTo = data['edu_dates_to']
	certificates = data['certifications']
	characterSkills = data['characteristics']
	userLangs = data['langs']
	userLangLevels = data['lang_levels']
	skills = data['skills']
	skillLevels = data['skill_levels']
	
	photoSRC = await getPhoto(chat_id)
	cvToForm = await cvForm(chat_id)
	
	filename = f'{surname.strip().capitalize()}_{name.strip().capitalize()}_cvboxuz_rezyume.pdf'
	
	if os.path.exists(f'cvs/{filename}'):
		os.remove(f'cvs/{filename}')
	markupD = ReplyKeyboardRemove()
	if cvToForm == 1:
		await MakePdfBlue(
			lang=str(langs[chat_id]),
			filename=filename,
			name=name.strip().capitalize(),
			surname=surname.strip().capitalize(),
			email=email,
			phone=phoneNumber,
			age=age,
			city=city.capitalize(),
			work_companies=workCompanies,
			work_roles=workRoles,
			work_dates_from=workDatesFrom,
			work_dates_to=workDatesTo,
			education_unis=educationUnis,
			education_levels=educationLevels,
			education_directions=educationDirections,
			education_dates_from=educationDatesFrom,
			education_dates_to=educationDatesTo,
			certifications=certificates,
			character_skills=characterSkills,
			languages=userLangs,
			language_levels=userLangLevels,
			skills=skills,
			skill_levels=skillLevels,
			photo=photoSRC
		)
	elif cvToForm == 2:
		await MakePdfBlueHor(
			lang=str(langs[chat_id]),
			filename=filename,
			name=name.capitalize(),
			surname=surname.capitalize(),
			email=email,
			phone=phoneNumber,
			age=age,
			city=city.capitalize(),
			work_companies=workCompanies,
			work_roles=workRoles,
			work_dates_from=workDatesFrom,
			work_dates_to=workDatesTo,
			education_unis=educationUnis,
			education_levels=educationLevels,
			education_directions=educationDirections,
			education_dates_from=educationDatesFrom,
			education_dates_to=educationDatesTo,
			certifications=certificates,
			character_skills=characterSkills,
			languages=userLangs,
			language_levels=userLangLevels,
			skills=skills,
			skill_levels=skillLevels,
			photo=photoSRC
		)
	elif cvToForm == 3:
		await MakePdfDefault(
			lang=str(langs[chat_id]),
			filename=filename,
			name=name.capitalize(),
			surname=surname.capitalize(),
			email=email,
			phone=phoneNumber,
			age=age,
			city=city.capitalize(),
			work_companies=workCompanies,
			work_roles=workRoles,
			work_dates_from=workDatesFrom,
			work_dates_to=workDatesTo,
			education_unis=educationUnis,
			education_levels=educationLevels,
			education_directions=educationDirections,
			education_dates_from=educationDatesFrom,
			education_dates_to=educationDatesTo,
			certifications=certificates,
			character_skills=characterSkills,
			languages=userLangs,
			language_levels=userLangLevels,
			skills=skills,
			skill_levels=skillLevels,
			photo=photoSRC
		)
	if langs[chat_id] == 'uz':
		caption = '🎉 Tabriklaymiz! \n💼 REZYUME tayyor boldi!'
		comment_caption = (f'Iltimos, ushbu <a href="https://g.page/r/CeJuALJGSCDjEBM/review"> '
		                   f'havola</a> bo\'yicha o\'tib yaxshi otziv qoldiring  ❤️')
	else:
		caption = '🎉 Поздравляем! \n💼 Резюме готово!'
		comment_caption = (f'Пожалуйсте, перейдя по <a href="https://g.page/r/CeJuALJGSCDjEBM/review"> '
		                   f'ссылке </a> оставьте хороший отзыв  ❤️')
	
	await asyncio.sleep(1.5)
	await bot.send_message(chat_id, caption, reply_markup=markupD)
	await asyncio.sleep(0.9)
	await bot.send_document(chat_id, f'cvs/{filename}',
	                        caption=f'{name} {surname}',
	                        file_name=f'{surname.strip()}_{name.strip()}_cvboxuz.pdf', reply_markup=markupD)
	await asyncio.sleep(0.4)
	await bot.send_chat_action(chat_id, ChatAction.TYPING)
	await bot.send_message(chat_id, comment_caption)
	await markupSender(chat_id, langs[chat_id])


async def getWebData(bot: Client, mess: Message):
	chat_id = mess.chat.id
	
	if mess.web_app_data:
		if chat_id not in users_dict:
			if mess.from_user.username:
				username = mess.from_user.username
			else:
				username = ''
			user = User(user_id=chat_id,
			            nick=mess.from_user.first_name,
			            username=username,
			            started_time=str(mess.date))
		else:
			user = users_dict[chat_id]
		
		data = json.loads(mess.web_app_data.data)
		
		photoSRC = await getPhoto(chat_id)
		cvToForm = await cvForm(chat_id)
		language = user.language
		
		if str(language) == 'ru' and cvToForm == 2:
			while cvToForm == 2:
				await bot.send_message(
					chat_id,
					'Извините, в данный момент нельзя создать резюме используя этот шаблон'
					'с русским языком. Выберите другой пожалуйсте')
				cvToForm = await cvForm(chat_id)
		
		user.end_time = time.time()
		user.cv_form = cvToForm
		
		try:
			name = data['name']
			surname = data['surname']
			phoneNumber = data['phone']
			email = data['email']
			age = data['age']
			city = data['city']
			workCompanies = data['work_companies']
			workRoles = data['work_roles']
			workDatesFrom = data['work_dates_from']
			workDatesTo = data['work_dates_to']
			educationUnis = data['edu_unis']
			educationLevels = data['edu_levels']
			educationDirections = data['edu_directs']
			educationDatesFrom = data['edu_dates_from']
			educationDatesTo = data['edu_dates_to']
			certificates = data['certifications']
			characterSkills = data['characteristics']
			userLangs = data['langs']
			userLangLevels = data['lang_levels']
			skills = data['skills']
			skillLevels = data['skill_levels']
		except Exception as e:
			logging.warning(e)
			await bot.send_message(
				chat_id,
				'При вводе данных в веб-приложении была допущена ошибка. Повторите попытку\n'
				'Web ilovada ma\'lumot yozishda hatolik ketgan. Qaytadan urinib ko\'ring')
		else:
			await bot.send_chat_action(chat_id, ChatAction.UPLOAD_DOCUMENT)
		
			user.age = age
			
			filename = f'{surname.strip().capitalize()}_{name.strip().capitalize()}_cvboxuz_rezyume.pdf'
			
			if os.path.exists(f'cvs/{filename}'):
				os.remove(f'cvs/{filename}')
			markupD = ReplyKeyboardRemove()
			if cvToForm == 1:
				await MakePdfBlue(
					lang=str(language),
					filename=filename,
					name=name.capitalize(),
					surname=surname.capitalize(),
					email=email,
					phone=phoneNumber,
					age=age,
					city=city.capitalize(),
					work_companies=workCompanies,
					work_roles=workRoles,
					work_dates_from=workDatesFrom,
					work_dates_to=workDatesTo,
					education_unis=educationUnis,
					education_levels=educationLevels,
					education_directions=educationDirections,
					education_dates_from=educationDatesFrom,
					education_dates_to=educationDatesTo,
					certifications=certificates,
					character_skills=characterSkills,
					languages=userLangs,
					language_levels=userLangLevels,
					skills=skills,
					skill_levels=skillLevels,
					photo=photoSRC
				)
			elif cvToForm == 2:
				await MakePdfBlueHor(
					lang=str(language),
					filename=filename,
					name=name.capitalize(),
					surname=surname.capitalize(),
					email=email,
					phone=phoneNumber,
					age=age,
					city=city.capitalize(),
					work_companies=workCompanies,
					work_roles=workRoles,
					work_dates_from=workDatesFrom,
					work_dates_to=workDatesTo,
					education_unis=educationUnis,
					education_levels=educationLevels,
					education_directions=educationDirections,
					education_dates_from=educationDatesFrom,
					education_dates_to=educationDatesTo,
					certifications=certificates,
					character_skills=characterSkills,
					languages=userLangs,
					language_levels=userLangLevels,
					skills=skills,
					skill_levels=skillLevels,
					photo=photoSRC
				)
			elif cvToForm == 3:
				await MakePdfDefault(
					lang=str(language),
					filename=filename,
					name=name.capitalize(),
					surname=surname.capitalize(),
					email=email,
					phone=phoneNumber,
					age=age,
					city=city.capitalize(),
					work_companies=workCompanies,
					work_roles=workRoles,
					work_dates_from=workDatesFrom,
					work_dates_to=workDatesTo,
					education_unis=educationUnis,
					education_levels=educationLevels,
					education_directions=educationDirections,
					education_dates_from=educationDatesFrom,
					education_dates_to=educationDatesTo,
					certifications=certificates,
					character_skills=characterSkills,
					languages=userLangs,
					language_levels=userLangLevels,
					skills=skills,
					skill_levels=skillLevels,
					photo=photoSRC
				)
			
			if langs[chat_id] == 'uz':
				caption = '🎉 Tabriklaymiz! \n💼 REZYUME tayyor boldi!'
				comment_caption = (f'Iltimos, ushbu <a href="https://g.page/r/CeJuALJGSCDjEBM/review"> '
				                   f'havola</a> bo\'yicha o\'tib yaxshi otziv qoldiring  ❤️')
				rate_caption = 'Iltimos, bot ishlashini baholang birdan beshgacha baholang:'
			
			else:
				caption = '🎉 Поздравляем! \n💼 Резюме готово!'
				comment_caption = (f'Пожалуйсте, перейдя по <a href="https://g.page/r/CeJuALJGSCDjEBM/review"> '
				                   f'ссылке </a> оставьте хороший отзыв  ❤️')
				rate_caption = 'Пожалуйста, оцените работу бота:'
			
			await bot.send_message(chat_id, caption, reply_markup=markupD)
			await asyncio.sleep(0.9)
			await bot.send_document(chat_id, f'cvs/{filename}',
			                        caption=f'{name} {surname}',
			                        file_name=f'{surname.strip()}_{name.strip()}_cvboxuz.pdf', reply_markup=markupD)
			await asyncio.sleep(0.4)
			await bot.send_chat_action(chat_id, ChatAction.TYPING)
			await bot.send_message(chat_id, comment_caption)
			await asyncio.sleep(1)
			
			rate_markup = ReplyKeyboardMarkup([[
				KeyboardButton('1'),
				KeyboardButton('2'),
				KeyboardButton('3'),
				KeyboardButton('4'),
				KeyboardButton('5')]], resize_keyboard=True, is_persistent=True, one_time_keyboard=True)
			rate: Message = await bot.ask(chat_id, rate_caption, reply_markup=rate_markup)
			if rate.text in ['1', '2', '3', '4', '5']:
				user.rate = int(rate.text)
			else:
				user.rate = 3
			spent_time_secs = user.cv_started_time - user.end_time
			spent_time = f'{int(spent_time_secs // 60)}:{int(spent_time_secs % 60)}'
			users_dict.update({chat_id: user})
			
			with open('succeed_users.csv', 'a', encoding='UTF-8') as file:
				writer = csv.writer(file, delimiter=',')
				if mess.from_user.username:
					username = mess.from_user.username
				else:
					username = 'None'
				
				writer.writerow([
					chat_id,
					mess.from_user.first_name,
					f'@{username}',
					str(user.status),
					spent_time,
					user.age,
					user.rate,
					user.cv_form
				])
		if langs[chat_id] == 'uz':
			caption = 'Rahmat!'
		else:
			caption = 'Спасибо!'
		await bot.send_message(chat_id, caption)
		await asyncio.sleep(1)
		await markupSender(chat_id=chat_id, lang=langs[chat_id])


bot.add_handler(MessageHandler(
	getStart, filters=(
		filters.command(['start']) | filters.regex('🔺Главное меню') | filters.regex('🔺Asosiy menyu'))))

bot.add_handler(MessageHandler(
	aboutUs,
	filters=(
		(filters.regex('Biz haqimizda') | filters.regex('О нас')) & filters.private)))

bot.add_handler(MessageHandler(
	sampleCVs,
	filters=(
		(filters.regex('Rezyume namunalari') | filters.regex('Образцы резюме')) & filters.private)))

bot.add_handler(MessageHandler(sampleCVMaker, filters=filters.command(['get_sample_cv'])))

bot.add_handler(MessageHandler(
	changeLanguage,
	filters=((filters.regex('🇺🇿Tilni ozgartirish') | filters.regex('🇷🇺Поменять язык')) & filters.private)))


async def func(_, __, mess: Message):
	if mess.web_app_data:
		return True


ifWebApp = filters.create(func)

bot.add_handler(MessageHandler(getWebData, ifWebApp))

bot.run()
