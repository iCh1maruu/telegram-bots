import asyncio
import os

from weasyprint import HTML


async def MakePdfBlueHor(
	lang,
	filename,
	name,
	surname,
	email,
	phone,
	city,
	age,
	work_companies,
	work_roles,
	work_dates_from,
	work_dates_to,
	education_unis,
	education_levels,
	education_directions,
	education_dates_from,
	education_dates_to,
	certifications,
	character_skills,
	languages,
	language_levels,
	skills,
	skill_levels,
	photo
):
	if lang == 'uz':
		html = """
		<html lang="ru-RU"></html>
		<head>
		  <meta charset="utf-8">
		  <title>CV</title>
		  <meta name="app-name" content="embed">
		  <link rel="preconnect" href="https://fonts.googleapis.com">
		  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
		  <link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap"
		        rel="stylesheet">
		  <link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap"
		        rel="stylesheet">
	    <style>
	    :root {
				--main-block-color: #15478B;
				--main-title-color: #119AB8;
				--main-progress-color: #15478B;
				--main-blue-color: #005061;
				--header-color: #8CC7D5;
				--nav-color: #239AB2;
			}
			@page {
				size: A3;
				margin: 0;
				width: 1190px;
			}
			* {
				/* width: 2481px;
				height: 3507px; */
				margin: 0;
			}
			body {
				font-family: 'Montserrat';
			}
			a {
				text-decoration: none;
			}
			.header {
				width: 100%;
				height: 350px;
				background-color: var(--header-color);
			}
			.header .username {
				color: var(--main-blue-color);
				vertical-align: middle;
				display: inline-block;
				margin-left: 2em;
			}
			.header .userphoto {
				width: 261px;
				height: 261px;
				object-fit: cover;
				vertical-align: middle;
				display: inline-block;
				margin-top: 1.24em;
				margin-left: 45%;
			}
			.nav {
				width: 100%;
				margin-top: 1.6em;
				height: 50px;
				background-color: var(--nav-color);
				text-align: center;
			}
			.nav ul li {
				width: 22%;
				display: inline-block;
				margin-top: 0.9em;
				font-weight: 550;
			}
			.nav ul .email {
				width: 32%;
			}

			.main-content{
				width: 93%;
				margin-left: auto;
				margin-right: auto;
				margin-top: 3em;
			}
			.exp h2 {
				color: var(--main-title-color);
				font-weight: 550;
				font-size: 24px;
			}
			.exp hr:not(.expItemHR) {
				margin-top: 0.7em;
				width: 98%;
				border-width: 1.4px;
				border-color: var(--main-block-color);
				border-style: solid;
			}
			.exp .expItem {
				margin-top: 1.6em;
				margin-left: 2em;
				font-size: 20px;
				line-height: 1.8;
			}
			.exp .expItem:first-of-type{
				margin-top: 0.55em;
			}
			.exp .expItem b {
				font-weight: 550;
			}
			.expItemHR {
				margin-left: 2.3em;
				margin-top: 1em;
				width: 90%;
				border-width: 0.8px;
				border-color: var(--main-block-color);
				border-style: solid;
			}

			.education {
				margin-top: 4em;
				margin-bottom: 3em;
			}
			.education h2 {
				color: var(--main-title-color);
				font-weight: 550;
				font-size: 24px;
			}
			.education hr:not(.expItemHR) {
				margin-top: 0.7em;
				width: 98%;
				border-width: 1.4px;
				border-color: var(--main-block-color);
				border-style: solid;
			}
			.education .eduItem {
				margin-top: 1.6em;
				margin-left: 2em;
				font-size: 20px;
				line-height: 1.8;
			}
			.education .eduItem:first-of-type{
				margin-top: 0.55em;
			}
			.education .eduItem b {
				font-weight: 550;
			}


			.skills {
				display: inline-block;  
				float: right;
				text-align: left;
				margin-right: 1em;
			}
			.skills h2 {
				color: var(--main-title-color);
				font-weight: 550;
				font-size: 24px;
				margin-right: 7.5em;
				position: relative;
			}
			.skills ul {
				font-size: 19;
				margin-top: 2em;
				display: inline-block;
				vertical-align: middle;
			}
			.skills .skillNames li p{
				display: inline;
			}
			.skills ul li {
				margin-top: 1.5em;
				vertical-align: middle;
			}
			.skills ul li:first-child {
				margin-top: 0;
			}
			.progress {
				width: 200px;
				height: 9px;
				display: inline-block;
				background: #E1E7ED;
				position:relative;
				vertical-align: middle;
			}
			.progress-line {
				background: var(--main-progress-color);
				height: 9px;
				position: absolute;
			}
			
			.skills hr {
				margin-top: 0.7em;
				border-width: 1.4px;
				border-color: var(--main-block-color);
				border-style: solid;
			}

			.languages {
				display: inline-block; 
				margin-left: 1em;
			}
			.languages h2 {
				color: var(--main-title-color);
				font-weight: 550;
				font-size: 24px;
			}
			.languages ul {
				font-size: 19;
				margin-top: 2em;
				display: inline-block;
			}
			.languages ul li p{
				display: inline-block;
			}
			.languages ul li {
				margin-top: 1.5em;
			}
			.languages ul li:first-child {
				margin-top: 0;
			}

			.languagesHR {
				margin-top: 0.7em;
				border-width: 1.4px;
				border-color: var(--main-block-color);
				border-style: solid;
				width: 91.139%;
				position: absolute;
				margin-top: 2.2em;
			}

			.certi_char {
				margin-top: 3.5em;
				margin-bottom: 3em;
			}
			.characteristics {
				display: inline-block; 
				margin-left: 1em;
			}
			.characteristics h2 {
				color: var(--main-title-color);
				font-weight: 550;
				font-size: 24px;
			}
			.characteristics ul {
				font-size: 19;
				margin-top: 2em;
				display: inline-block;
			}
			.characteristics ul li p{
				display: inline-block;
			}
			.characteristics ul li {
				margin-top: 1.5em;
			}
			.characteristics ul li:first-child {
				margin-top: 0;
			}

			.certifications {
				display: inline-block;  
				float: right;
				margin-right: 10.7em; 
			}
			.certifications h2 {
				color: var(--main-title-color);
				font-weight: 550;
				font-size: 24px;
			}
			.certifications ul {
				font-size: 19;
				margin-top: 2em;
				display: inline-block;
			}
			.certifications ul li p{
				display: inline-block;
			}
			.certifications ul li {
				margin-top: 1.5em;
			}
			.certifications ul li:first-child {
				margin-top: 0;
			}
			.certifications hr {
				margin-top: 0.7em;
				border-width: 1.4px;
				border-color: var(--main-block-color);
				border-style: solid;
			}

			.watermark {
				width: 205px;
				float: right;
				margin-right: 1.6em;
				margin-top: 100%;
				vertical-align: bottom;
			}
	    </style>
		</head>
		<body>"""

		toStylePass = """"""
		if photo:
			toStylePass = """
			<style>
	      .header .userphoto {
	        width: 261px;
	        height: 261px;
	        object-fit: cover;
	        vertical-align: middle;
	        display: inline-block;
	        margin-top: 1.24em;
	        margin-left: 45%;""" + f"""
	        background-image: url('{photo}');
	        background-position:center;
	        background-size: contain;""" + """
	      }
	    </style>"""
		else:
			toStylePass = """
			<style>
	      .header .userphoto {
	        width: 261px;
				  height: 261px;
				  object-fit: cover;
				  vertical-align: middle;
				  display: inline-block;
				  margin-top: 1.24em;
				  margin-left: 45%;
	      }
	    </style>"""

		html = f"""{html}
		<div class="header">
    <h1 class="username">{name} {surname}</h1>
    <div class="userphoto"></div>
    {toStylePass}
    <div class="nav">
      <ul style="list-style: none;">
        <li>
          {city}
        </li>
        <li>
          Telefon: {phone}
        </li>
        <li class="email">
          Email: {email}
        </li>
        <li>
          Yosh: {age}
        </li>
      </ul>
    </div>
  </div>

	<div class="main-content">
    <div class="exp">
      <h2>Ish tajribasi:</h2>
      <hr>"""
		for i in range(len(work_companies)):
			html = f"""{html}
			<div class="expItem">
        <b>{work_companies[i]}, {work_roles[i]}</b><br>
        <i>{work_dates_from[i]} - {work_dates_to[i]}</i>
      </div>
			"""
		html = f"""{html}
		</div>

    <div class="education">
      <h2>Ta'lim darajasi:</h2>
      <hr>
		"""
		for i in range(len(education_unis)):
			level = ''
			if education_levels[i] == 'Bachelor':
				level = 'Bakalavr'
			elif education_levels[i] == 'school':
				level = "O'rta ta'lim"
			elif education_levels[i] == 'college':
				level = 'Kolledj'
			elif education_levels[i] == 'master':
				level = 'Magistratura'
			elif education_levels[i] == 'phd':
				level = 'PhD'
			html = f"""{html}
			<div class="eduItem">
        <b>{education_unis[i]}, {level}, {education_directions[i]}</b><br>
        <i>{education_dates_from[i]} - {education_dates_to[i]}</i>
      </div>
			"""
		html = f"""{html}
		</div>

    <hr class="languagesHR">

    <!-- LANGUAGES -->

    <div class="languages">
      <h2>Chet tillari:</h2>
      <ul>
		"""
		for i in range(len(languages)):
			html = f"""{html}
			<li>
        <p>{languages[i]}</p>
      </li>
			"""
		html = f"""{html}</ul><ul style="list-style: none;">"""

		for i in range(len(language_levels)):
			level = '50%'
			if language_levels[i] == "basic":
				level = '30%'
			elif language_levels[i] == "middle":
				level = '55%'
			elif language_levels[i] == "pro":
				level = '100%'
			html = f"""{html}
			<li>
        <div class="progress">
          <div class="progress-line" style="width: {level};"></div>
        </div>
      </li>
			"""
		html = f"""{html}
		</ul>
    </div>

    <!-- SKILLS -->

    <div class="skills">
      <h2>Kompyuter savodxonligi:</h2>
      <ul class="skillNames">
		"""

		for i in range(len(skills)):
			html = f"""{html}
			<li>
        <p>{skills[i]}</p>
      </li>
			"""
		html = f"""{html}</ul><ul class="progressive" style="list-style: none;">"""
		for i in range(len(skill_levels)):
			level = '50%'
			if skill_levels[i] == "basic":
				level = '30%'
			elif skill_levels[i] == "middle":
				level = '55%'
			elif skill_levels[i] == "pro":
				level = '100%'
			html = f"""{html}
			<li>
        <div class="progress">
          <div class="progress-line" style="width: {level};"></div>
        </div>
      </li>
			"""
		html = f"""{html}
			</ul>
    </div>

    <!-- CERTIFICATES AND CHARACTERISTICS -->

    <div class="certi_char">

      <hr class="languagesHR">

      <!-- CHARACTERISTICS -->

      <div class="characteristics">
        <h2>Ko'nikmalar:</h2>
        <ul>
		"""

		for i in range(len(character_skills)):
			html = f"""{html}
			<li>
        <p>{character_skills[i]}</p>
      </li>
			"""
		html = f"""{html}
			</ul>
        
    </div>

    <!-- CERTIFICATIONS -->

    <div class="certifications">
      <h2>O'quv kurslari, sertifikatlar:</h2>
      <ul>
		"""

		for i in range(len(certifications)):
			html = f"""{html}
			<li>
        <p>{certifications[i]}</p>
      </li>
			"""
		html = f"""{html}
							</ul>  
		        </div>
		      </div>
		    </div>
		    <img src="wrap.png" class="watermark" alt="">
		
			</body>
		</html>
		"""

		with open(f'cvs/{str(filename).replace(".pdf", ".html")}', 'w', encoding='UTF-8') as f:
			f.write(html)

		HTML(f'cvs/{str(filename).replace(".pdf", ".html")}', encoding='UTF-8').write_pdf(f'cvs/{filename}')

		os.remove(f'cvs/{str(filename).replace(".pdf", ".html")}')
		if photo:
			os.remove(photo)


async def MakePdfBlue(
	lang,
	filename,
	name,
	surname,
	email,
	phone,
	age,
	city,
	work_companies,
	work_roles,
	work_dates_from,
	work_dates_to,
	education_unis,
	education_levels,
	education_directions,
	education_dates_from,
	education_dates_to,
	certifications,
	character_skills,
	languages,
	language_levels,
	skills,
	skill_levels,
	photo
):
	if lang == 'ru':
		html = """
<html lang="ru-RU"></html>
<head>
  <meta charset="utf-8">
  <title>CV</title>
  <meta name="app-name" content="embed">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap"
        rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap"
        rel="stylesheet">
  <style>
    :root {
      --main-block-color: #15478B;
      --main-title-color: #119AB8;
      --main-progress-color: #15478B;
      --main-blue-color: #005061;
    }
    @page {
      size: A3;
      margin: 0;
      width: 1190px;
    }
    * {
	     /* width: 2481px;
	     height: 3507px; */
	     margin: 0;
    }
    body {
      font-family: 'Montserrat';
    }
    a {
      text-decoration: none;
    }
    .aside {
     width: 34%;
     height: 4960px;
     background: #89C5D2;
     text-align: center;
     display: inline-block;
    }
    .aside .userPhoto {
     width: 261px;
     height: 261px;
     object-fit: cover;
     margin-top: 3.5em;
    }
    .username {
     color: var(--main-blue-color);
     text-transform: uppercase;
     font-family: 'Montserrat';
     letter-spacing: 1.2;
     margin-top: 1.3em;
    }
    .main-content {
     width: 60%;
     display: inline-block;
     vertical-align: top; 
     margin-top: 3.5em;
     margin-left: 3.5em;
    }
    .footTitle {
     margin-top: 0.4em;
     font-family: 'Montserrat';
     font-weight: 500;
     text-align: left;
     font-size: 19;
     margin-left: 2.9em;
     line-height: 1.5;
    }
    .contacts {
     margin-top: 2em;
     font-family: 'Montserrat';
     text-align: left;
    }
    .contacts h4 {
      margin-left: 1.7em;
      font-weight: 600;
      color: var(--main-blue-color);
      font-size: 23;
    }
    .contacts li {
     margin-top: 0.7em;
     color: black;
     font-family: 'Montserrat';
     font-weight: 500;
     margin-left: 1em;
     font-size: 19;
    }
    .contacts li:first-child{
     margin-top: 1em;
    }
    .contacts a {
     color: black;
     font-family: 'Montserrat';
     font-weight: 500;
    }
    .exp h2 {
     color: var(--main-title-color);
     font-weight: 600;
    }
    .exp ul {
     margin-top: 1.2em;
     font-weight: 500;
     font-size: 18;
    }
    .exp ul li {
     margin-top: 1.5em;
    }
    .exp ul li:first-child {
     margin-top: 0;
    }
    hr {
      margin-top: 1.3em;
      width: 92%;
      border-width: 1.5px;
      border-color: var(--main-block-color);
      border-style: solid;
    }
    .underLangHr {
      margin-top: 2.2em;
    }
    .exp .workItem {
     max-width: 89%;
     line-height: 2;
     display: block;
     white-space: normal;
     word-wrap: normal;
    }
    .education {
     margin-top: 3em;
    }
    .education h2 {
     color: var(--main-title-color);
     font-weight: 600;
    }
    .education ul {
     margin-top: 1.2em;
     font-size: 19;
     font-weight: 500;
    }
    .education ul li {
     margin-top: 1.5em;
    }
    .education ul li:first-child {
     margin-top: 0;
    }
    .education ul hr {
     margin-top: 2em;
     width: 92%;
     border-width: 1.2px;
     border-color: var(--main-block-color);
     border-style: solid;
    }
    .education .eduItem {
     max-width: 89%;
     line-height: 2;
     display: block;
     white-space: normal;
     word-wrap: break-word;
    }
    
    .skills {
     margin-top: 2em;
    }
    .skills h2 {
     color: var(--main-title-color);
     font-weight: 600;
    }
    .skills ul {
     font-size: 19;
     margin-top: 1.2em;
     display: inline-block;
    }
    .skills ul li p{
     display: inline-block;
    }
    .skills ul li {
     margin-top: 1.5em;
    }
    .skills ul li:first-child {
     margin-top: 0;
    }
    .progress {
     width: 200px;
     height: 9px;
     display: inline-block;
     background: #E1E7ED;
     position: relative;
     margin-left: 0.5em;
     vertical-align: middle;
    }
    .progress-line {
     background: var(--main-progress-color);
     height: 9px;
     position: absolute;
     overflow: hidden;
    }
    .watermark {
      width: 205px;
      position: absolute;
      margin-left: auto;
      left: 81.7%;
      top: -3.8em;
    }
    .certifications {
      margin-top: 2em;
      font-size: 17;
    }
    .certifications ul {
     font-size: 19;
     margin-top: 1.2em;
    }
    .certifications h2 {
      color: var(--main-title-color);
      font-weight: 600;
    }
    .certifications li {
      margin-top: 1.5em;
    }
    .certifications li:first-child {
      margin-top: 0;
    }
    .characteristics {
      margin-top: 3em;
      font-size: 17;
    }
    .characteristics ul {
      margin-top: 1.2em;
      font-size: 19;
    }
    .characteristics h2 {
      color: var(--main-title-color);
      font-weight: 600;
    }
    .characteristics li {
      margin-top: 1.5em;
    }
    .characteristics li:first-child {
      margin-top: 0;
    }
  </style>
  </head>
	<body>
    <div class="aside">
"""
		if photo:
			html = f"""{html}
				<img src="{photo}" alt="avatar" class="userPhoto">
				<h1 class="username">{name} {surname}</h1>
				<h4 class="footTitle">Выпускник {education_unis[0]}<br>"""
		else:
			html = f"""{html}
	<h1 class="username" style="margin-top: 2em;">{name} {surname}</h1>
  <h4 class="footTitle">Выпускник {education_unis[0]}<br>"""
		html = f"""{html}
    Возраст {age} лет
  </h4>
  <div class="contacts">
    <h4>Контакты:</h4>
    <ul style="list-style: none;">
      <li>
        <a href="tel:998912545650" class="phone">
          <p>
            Тел: {phone}
          </p>
        </a>
      </li>
      <li>
        Email: <a href="mailto:cardano@gmail.com">{email}</a>
      </li>
    </ul>
  </div>
</div>
<div class="main-content">
  <img src="wrap.png" class="watermark">

  <div class="exp">
    <h2>Опыт работы:</h2>
    <ul style="list-style: none;">
"""
		for i in range(len(work_companies)):
			html = f"""{html}
				<li>
		      <p class="workItem" style="font-weight: 500;">
	          <b>{work_companies[i]}, {work_roles[i]}</b><br>
		        <i>{work_dates_from[i]} - {work_dates_to[i]}</i>
		      </p>
		    </li>"""
		html = f"""{html}
</ul>
  </div>
  <hr>
  <div class="education">
    <h2>Образование:</h2>
    <ul style="list-style: none;">"""
		for i in range(len(education_levels)):
			role = ''
			if education_levels[i] == 'Bachelor':
				role = 'Бакалавр'
			elif education_levels[i] == 'school':
				role = 'Среднее образование'
			elif education_levels[i] == 'college':
				role = 'Колледж'
			elif education_levels[i] == 'master':
				role = 'Магистратура'
			elif education_levels[i] == 'phd':
				role = 'PhD'
			html = f"""{html}
				<li>
	        <div class="eduItem">
	          <b>{education_unis[i]}, {role}, {education_directions[i]}</b><br>
		        <i>{education_dates_from[i]} - {education_dates_to[i]}</i>
	        </div>
        </li>"""
		html = f"""{html}
				</ul>
		  </div>
		  <hr>
			
			  <!-- LANGUAGES -->
			
		  <div class="skills">
		    <h2>Владение языками:</h2>
		    <ul>
		"""
		for i in range(len(languages)):
			html = f"""{html}
				<li>
	        <p>{languages[i]}</p>
	      </li>"""
		html = f"""{html}</ul><ul style="list-style: none;">"""
		for i in range(len(language_levels)):
			level = ''
			if language_levels[i] == 'basic':
				level = '30%'
			elif language_levels[i] == 'middle':
				level = '55%'
			elif language_levels[i] == 'pro':
				level = '100%'
			html = f"""{html}
				<li>
	        <div class="progress">
	          <div class="progress-line" style="width: {level};"></div>
	        </div>
	      </li>"""
		html = f"""{html}
				</ul>
		  </div>
		  <hr class="underLangHr">
		
		  <div class="skills">
		    <h2>Навыки:</h2>
		    <ul>"""
		for i in range(len(skills)):
			html = f"""{html}
				<li>
	        <p>{skills[i]}</p>
	      </li>"""
		html = f"""{html}</ul><ul style="list-style: none;">"""
		for i in range(len(skill_levels)):
			level = ''
			if skill_levels[i] == 'basic':
				level = '30%'
			elif skill_levels[i] == 'middle':
				level = '55%'
			elif skill_levels[i] == 'pro':
				level = '100%'
			html = f"""{html}
				<li>
	        <div class="progress">
	          <div class="progress-line" style="width: {level};"></div>
	        </div>
	      </li>"""
		html = f"""{html}
				</ul>
		  </div>
				
		  <hr class="underLangHr">
		  <div class="characteristics">
		    <h2>Характерные качества:</h2>
		    <ul>"""
		for i in range(len(character_skills)):
			html = f"""{html}
				<li>
	        {character_skills[i]}
	      </li>"""
		html = f"""{html}
				</ul>
		  </div>
	
		  <hr class="underLangHr">
		  <div class="certifications">
		    <h2>Сертификаты:</h2>
				<ul>"""
		for i in range(len(certifications)):
			html = f"""{html}
      <li>
        {certifications[i]}
      </li>"""
		html = f"""{html}
							</ul>
			      </div>
					</div>
				</body>
			</html>"""

		with open(f'cvs/{str(filename).replace(".pdf", ".html")}', 'w', encoding='UTF-8') as f:
			f.write(html)

		HTML(f'cvs/{str(filename).replace(".pdf", ".html")}', encoding='UTF-8').write_pdf(f'cvs/{filename}')

		os.remove(f'cvs/{str(filename).replace(".pdf", ".html")}')
		if photo:
			os.remove(photo)

	elif lang == 'uz':
		html = """
		<html lang="ru-RU"></html>
		<head>
		  <meta charset="utf-8">
		  <title>CV</title>
		  <meta name="app-name" content="embed">
		  <link rel="preconnect" href="https://fonts.googleapis.com">
		  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
		  <link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap"
		        rel="stylesheet">
		  <link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap"
		        rel="stylesheet">
		  <style>
		    :root {
		      --main-block-color: #15478B;
		      --main-title-color: #119AB8;
		      --main-progress-color: #15478B;
		      --main-blue-color: #005061;
		    }
		    @page {
		      size: A3;
		      margin: 0;
		      width: 1190px;
		    }
		    * {
			     /* width: 2481px;
			     height: 3507px; */
			     margin: 0;
		    }
		    body {
		      font-family: 'Montserrat';
		    }
		    a {
		      text-decoration: none;
		    }
		    .aside {
		     width: 34%;
		     height: 4960px;
		     background: #89C5D2;
		     text-align: center;
		     display: inline-block;
		    }
		    .aside .userPhoto {
		     width: 261px;
		     height: 261px;
		     object-fit: cover;
		     margin-top: 3.5em;
		    }
		    .username {
		     color: var(--main-blue-color);
		     text-transform: uppercase;
		     font-family: 'Montserrat';
		     letter-spacing: 1.2;
		     margin-top: 1.3em;
		    }
		    .main-content {
		     width: 60%;
		     display: inline-block;
		     vertical-align: top; 
		     margin-top: 3.5em;
		     margin-left: 3.5em;
		    }
		    .footTitle {
		     margin-top: 0.4em;
		     font-family: 'Montserrat';
		     font-weight: 500;
		     text-align: left;
		     margin-left: 2.9em;
		     line-height: 1.5;
		    }
		    .contacts {
		     margin-top: 2em;
		     font-family: 'Montserrat';
		     text-align: left;
		    }
		    .contacts h2 {
		      margin-left: 1.7em;
		      font-weight: 600;
		      color: var(--main-blue-color);
		    }
		    .contacts li {
		     margin-top: 0.7em;
		     color: black;
		     font-family: 'Montserrat';
		     font-weight: 600;
		     font-size: 21px;
		    }
		    .contacts li:first-child{
		     margin-top: 1em;
		    }
		    .contacts a {
		     color: black;
		     font-family: 'Montserrat';
		     font-weight: 600;
		    }
		    .exp h2 {
		     color: var(--main-title-color);
		     font-weight: 600;
		    }
	      .exp ul {
		      margin-top: 1.2em;
		      font-weight: 600;
		    }
		    .exp ul li {
	        margin-top: 1.5em;
		      font-size: 24px;
		    }
		    .exp ul li:first-child {
		      margin-top: 0;
		    }
		    hr {
		      margin-top: 1.3em;
		      width: 92%;
		      border-width: 1.5px;
		      border-color: var(--main-block-color);
		      border-style: solid;
		    }
		    .underLangHr {
		      margin-top: 2.2em;
		    }
		    .exp .workItem {
					max-width: 89%;
					line-height: 2;
					display: block;
					white-space: normal;
          word-wrap: normal;
		    }
		    .education {
		     margin-top: 3em;
		    }
		    .education h2 {
		     color: var(--main-title-color);
		     font-weight: 600;
		    }
		    .education ul {
		     margin-top: 1.2em;
		     font-weight: 600;
		    }
		    .education ul li {
			     font-size: 24px;
			     margin-top: 1.5em;
		    }
		    .education ul li:first-child {
		     margin-top: 0;
		    }
		    .education ul hr {
		     margin-top: 2em;
		     width: 92%;
		     border-width: 1.2px;
		     border-color: var(--main-block-color);
		     border-style: solid;
		    }
		    .education .eduItem {
		     max-width: 89%;
		     line-height: 2;
		     display: block;
		     white-space: normal;
		     word-wrap: break-word;
		    }
		    .skills {
		     margin-top: 2em;
		    }
		    .skills h2 {
		     color: var(--main-title-color);
		     font-weight: 600;
		    }
		    .skills ul {
		     margin-top: 1.2em;
		     display: inline-block;
		     font-weight: 600;
		    }
		    .skills ul li p{
		     font-size: 24px;
		     display: inline-block;
		    }
		    .skills ul li {
		     margin-top: 1.5em;
		    }
		    .skills ul li:first-child {
		     margin-top: 0;
		    }
		    .progress {
		     width: 200px;
		     height: 9px;
		     display: inline-block;
		     background: #E1E7ED;
		     position: relative;
		     margin-left: 0.5em;
		     vertical-align: middle;
		    }
		    .progress-line {
		     background: var(--main-progress-color);
		     height: 9px;
		     position: absolute;
		     overflow: hidden;
		    }
		    .watermark {
		      width: 205px;
		      position: absolute;
		      margin-left: auto;
		      left: 81.7%;
		      top: -3.8em;
		    }
		    .certifications {
		      margin-top: 2em;
		      font-weight: 600;
		    }
		    .certifications ul {
		     margin-top: 1.2em;
		    }
		    .certifications h2 {
		      color: var(--main-title-color);
		      font-weight: 600;
		    }
		    .certifications li {
		      font-size: 24px;
		      margin-top: 1.5em;
		    }
		    .certifications li:first-child {
		      margin-top: 0;
		    }
		    .characteristics {
		      margin-top: 3em;
		      font-weight: 600;
		    }
		    .characteristics ul {
		      margin-top: 1.2em;
		    }
		    .characteristics h2 {
		      color: var(--main-title-color);
		      font-weight: 600;
		    }
		    .characteristics li {
		      font-size: 24px;
		      margin-top: 1.5em;
		    }
		    .characteristics li:first-child {
		      margin-top: 0;
		    }
		  </style>
		  </head>
			<body>
		    <div class="aside">
		"""
		if photo:
			html = f"""{html}
				<img src="{photo}" alt="avatar" class="userPhoto">
				<h1 class="username">{name} {surname}</h1>
				<h4 class="footTitle">{education_unis[0]} bitiruvchisi<br>"""
		else:
			html = f"""{html}
			<h1 class="username" style="margin-top: 2em;">{name} {surname}</h1>
		  <h4 class="footTitle">{education_unis[0]} bitiruvchisi<br>"""
		html = f"""{html}
		    Yosh: {age}
		  </h4>
		  <div class="contacts">
		    <h2>Kontaktlar:</h2>
		    <ul style="list-style: none;">
		      <li>
		        <a href="tel:998912545650" class="phone">
		          <p>
		            Telefon: {phone}
		          </p>
		        </a>
		      </li>
		      <li>
		        Email: <a href="mailto:cardano@gmail.com">{email}</a>
		      </li>
		    </ul>
		  </div>
		</div>
		<div class="main-content">
		  <img src="wrap.png" class="watermark">

		  <div class="exp">
		    <h2>Ish tajribasi:</h2>
		    <ul style="list-style: none;">
		"""
		for i in range(len(work_companies)):
			html = f"""{html}
						<li>
				      <p class="workItem">
				        <i style="font-weight: 500;">{work_companies[i]}</i>, {work_roles[i]}<br>
				        <b style="font-weight: 500;">{work_dates_from[i]} - {work_dates_to[i]}</b>
				      </p>
				    </li>"""
		html = f"""{html}
		</ul>
		  </div>
		  <hr>
		  <div class="education">
		    <h2>Ta'lim darajasi:</h2>
		    <ul style="list-style: none;">"""
		for i in range(len(education_levels)):
			level = ''
			if education_levels[i] == 'Bachelor':
				level = 'Bakalavr'
			elif education_levels[i] == 'school':
				level = "O'rta ta'lim"
			elif education_levels[i] == 'college':
				level = 'Kolledj'
			elif education_levels[i] == 'master':
				level = 'Magistratura'
			elif education_levels[i] == 'phd':
				level = 'PhD'
			html = f"""{html}
						<li>
			        <div class="eduItem">
			          <i style="font-weight: 500;">{education_unis[i]}</i>, {level}, {education_directions[i]}<br>
		            <b style="font-weight: 500;">{education_dates_from[i]} - {education_dates_to[i]}</b> 
			        </div>
		        </li>"""
		html = f"""{html}
						</ul>
				  </div>
				  <hr>

					  <!-- LANGUAGES -->

				  <div class="skills">
				    <h2>Chet tillari:</h2>
				    <ul>
				"""
		for i in range(len(languages)):
			html = f"""{html}
						<li>
			        <p>{languages[i]}</p>
			      </li>"""
		html = f"""{html}</ul><ul style="list-style: none;">"""
		for i in range(len(language_levels)):
			level = ''
			if language_levels[i] == "basic":
				level = '30%'
			elif language_levels[i] == "middle":
				level = '55%'
			elif language_levels[i] == "pro":
				level = '100%'
			html = f"""{html}
						<li>
			        <div class="progress">
			          <div class="progress-line" style="width: {level};"></div>
			        </div>
			      </li>"""
		html = f"""{html}
						</ul>
				  </div>
				  <hr class="underLangHr">

				  <div class="skills">
				    <h2>Kompyuter savodxonligi:</h2>
				    <ul>"""
		for i in range(len(skills)):
			html = f"""{html}
						<li>
			        <p>{skills[i]}</p>
			      </li>"""
		html = f"""{html}</ul><ul style="list-style: none;">"""
		for i in range(len(skill_levels)):
			level = ''
			if skill_levels[i] == "basic":
				level = '30%'
			elif skill_levels[i] == "middle":
				level = '55%'
			elif skill_levels[i] == "pro":
				level = '100%'
			html = f"""{html}
						<li>
			        <div class="progress">
			          <div class="progress-line" style="width: {level};"></div>
			        </div>
			      </li>"""
		html = f"""{html}
						</ul>
				  </div>

				  <hr class="underLangHr">
				  <div class="characteristics">
				    <h2>Ko'nikmalar:</h2>
				    <ul>"""
		for i in range(len(character_skills)):
			html = f"""{html}
						<li>
			        {character_skills[i]}
			      </li>"""
		html = f"""{html}
						</ul>
				  </div>

				  <hr class="underLangHr">
				  <div class="certifications">
				    <h2>O'quv kurslari, sertifikatlar:</h2>
						<ul>"""
		for i in range(len(certifications)):
			html = f"""{html}
		      <li>
		        {certifications[i]}
		      </li>"""
		html = f"""{html}
									</ul>
					      </div>
							</div>
						</body>
					</html>"""

		with open(f'cvs/{str(filename).replace(".pdf", ".html")}', 'w', encoding='UTF-8') as f:
			f.write(html)

		HTML(f'cvs/{str(filename).replace(".pdf", ".html")}', encoding='UTF-8').write_pdf(f'cvs/{filename}')

		os.remove(f'cvs/{str(filename).replace(".pdf", ".html")}')
		if photo:
			os.remove(photo)


async def MakePdfDefault(
	lang,
	filename,
	name,
	surname,
	email,
	phone,
	city,
	age,
	work_companies,
	work_roles,
	work_dates_from,
	work_dates_to,
	education_unis,
	education_levels,
	education_directions,
	education_dates_from,
	education_dates_to,
	certifications,
	character_skills,
	languages,
	language_levels,
	skills,
	skill_levels,
	photo):
	if lang == 'ru':
		html = """
      <html lang="ru-RU"></html>
        <head>
          <meta charset="utf-8">
          <title>CV</title>
          <meta name="app-name" content="embed">
          <link rel="preconnect" href="https://fonts.googleapis.com">
          <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
          <link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap" rel="stylesheet">
          <link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
          <style>
            :root {
							--main-block-color: #b29772;
							--main-title-color: #8F754F;
							--main-progress-color: #6d421d;
							--main-blue-color: #DDD;
						}
						@page {
							size: A3;
							margin: 0;
							width: 1190px;
						}
						* {
							/* width: 2481px;
							height: 3507px; */
							margin: 0;
						}
						body {
							font-family: 'Montserrat';
						}
						a {
							text-decoration: none;
						}
						.aside {
							width: 34%;
							height: 4960px;
							background: #222;
							text-align: center;
							display: inline-block;
						}
						.aside .userPhoto {
							width: 261px;
							height: 261px;
							object-fit: cover;
							margin-top: 3.5em;
						}
						.username {
							color: #DDD;
							text-transform: uppercase;
							font-family: 'Montserrat';
							letter-spacing: 1.2;
							margin-top: 1em;
							font-size: 32px;
							text-shadow: 0 0 30px #555;
						}
						.main-content {
							width: 60%;
							display: inline-block;
							vertical-align: top; 
							margin-top: 3.5em;
							margin-left: 3.5em;
						}
						.footTitle {
							margin-top: 0.4em;
							font-family: 'Montserrat';
							font-weight: 500;
							text-align: left;
							font-size: 19;
							margin-left: 2.9em;
							line-height: 1.5;
							color: #DDD;
							text-shadow: 0 0 20px #555;
						}
						.contacts {
							margin-top: 2em;
							font-family: 'Montserrat';
							text-align: left;
						}
						.contacts h4 {
							margin-left: 1.7em;
							font-weight: 600;
							color: #ddd;
							text-shadow: 0 0 30px #555;
							font-size: 23;
						}
						.contacts li {
							margin-top: 0.7em;
							color: #DDD;
							text-shadow: 0 0 20px #555;
							font-family: 'Montserrat';
							font-weight: 500;
							margin-left: 1em;
							font-size: 20;
						}
						.contacts li:first-child{
							margin-top: 1em;
						}
						.contacts a {
							color: #DDD;
							font-family: 'Montserrat';
							font-weight: 500;
						}
						.exp h2 {
							color: var(--main-title-color);
							font-weight: 600;
						}
						.exp ul {
							margin-top: 1.2em;
							font-weight: 500;
							font-size: 18;
						}
						.exp ul li {
							margin-top: 2em;
						}
						.exp ul li:first-child {
							margin-top: 0;
						}
						hr {
							margin-top: 1.3em;
							width: 92%;
							border-width: 1.5px;
							border-color: var(--main-block-color);
							border-style: solid;
						}
						.underLangHr {
							margin-top: 2.2em;
						}
						.exp .workItem {
							display: block;
							line-height: 2;
						}
						.education {
							margin-top: 3em;
						}
						.education h2 {
							color: var(--main-title-color);
							font-weight: 600;
						}
						.education ul {
							margin-top: 1.2em;
							font-size: 19;
							font-weight: 500;
						}
						.education ul li {
							margin-top: 2em;
						}
						.education ul li:first-child {
							margin-top: 0;
						}
						.education ul hr {
							margin-top: 2em;
							width: 92%;
							border-width: 1.2px;
							border-color: var(--main-block-color);
							border-style: solid;
						}
						.education .eduItem {
							max-width: 89%;
							line-height: 2;
							display: block;
							white-space: normal;
							word-wrap: break-word;
						}
						
						.skills {
							margin-top: 2em;
						}
						.skills h2 {
							color: var(--main-title-color);
							font-weight: 600;
						}
						.skills ul {
							font-size: 19;
							margin-top: 1.2em;
							display: inline-block;
						}
						.skills ul li p{
							display: inline-block;
						}
						.skills ul li {
							margin-top: 1.5em;
						}
						.skills ul li:first-child {
							margin-top: 0;
						}
						.progress {
							width: 200px;
							height: 9px;
							display: inline-block;
							background: #E1E7ED;
							position: relative;
							margin-left: 0.5em;
							vertical-align: middle;
						}
						.progress-line {
							background: var(--main-progress-color);
							height: 9px;
							position: absolute;
							overflow: hidden;
						}
						.watermark {
							width: 205px;
							position: absolute;
							margin-left: auto;
							left: 82%;
							top: -3.8em;
						}
						.certifications {
							margin-top: 2em;
							font-size: 17;
						}
						.certifications ul {
							font-size: 19;
							margin-top: 1.2em;
						}
						.certifications h2 {
							color: var(--main-title-color);
							font-weight: 600;
						}
						.certifications li {
							margin-top: 1.5em;
						}
						.certifications li:first-child {
							margin-top: 0;
						}
						.characteristics {
							margin-top: 3em;
							font-size: 17;
						}
						.characteristics ul {
							margin-top: 1.2em;
							font-size: 19;
						}
						.characteristics h2 {
							color: var(--main-title-color);
							font-weight: 600;
						}
						.characteristics li {
							margin-top: 1.5em;
						}
						.characteristics li:first-child {
							margin-top: 0;
						}
          </style>
        </head>"""
		if photo:
			html = f"""{html}
					<body>
            <div class="aside">
              <img src="{photo}" alt="avatar" class="userPhoto">
              <h1 class="username">{name} {surname}</h1>
						  <h4 class="footTitle">Выпускник {education_unis[0]}<br>
						    Возраст {age} лет
					    </h4>
              <div class="contacts">
						    <h4>Контакты:</h4>
						    <ul style="list-style: none;">
						      <li>
						        <a href="tel:{str(phone).replace('+', '')}" class="phone">
						          <p>
						            Тел: {phone}
						          </p>
						        </a>
						      </li>
                  <li>
                    Email: <a href="mailto:{email}">{email}</a>
                  </li>
                </ul>
              </div>
            </div>
    
            <div class="main-content">
              <img src="wrap.png" class="watermark">
    
              <div class="exp">
                <h2>Опыт работы:</h2>
                <ul style="list-style: none;">
      """
		else:
			html = f"""{html}<body>
			            <div class="aside">
			              <h1 class="username" style="margin-top: 2em;">{name} {surname}</h1>
									  <h4 class="footTitle">Выпускник {education_unis[0]}<br>
									    Возраст {age} лет
			              <div class="contacts">
									    <h4>Контакты:</h4>
									    <ul style="list-style: none;">
									      <li>
									        <a href="tel:{str(phone).replace('+', '')}" class="phone">
									          <p>
									            Тел: {phone}
									          </p>
									        </a>
									      </li>
			                  <li>
			                    Email: <a href="mailto:{email}">{email}</a>
			                  </li>
			                </ul>
			              </div>
			            </div>

			            <div class="main-content">
			              <img src="wrap.png" class="watermark">

			              <div class="exp">
			                <h2>Опыт работы:</h2>
			                <ul style="list-style: none;">
			      """
		for i in range(len(work_companies)):
			html = f"""{html}
        <li>
          <p class="workItem">
            <b style="font-weight: 500;">{work_companies[i]}, {work_roles[i]}</b><br>
            {work_dates_from[i]} - {work_dates_to[i]}
          </p>
        </li>"""

		html = f"""{html}
      </ul>
    </div>
    <hr>
    <div class="education">
      <h2>Образование:</h2>
      <ul style="list-style: none;">"""

		for i in range(len(education_levels)):
			level = ''
			if education_levels[i] == 'Bachelor':
				level = 'Бакалаврр'
			elif education_levels[i] == 'school':
				level = "Среднее образование"
			elif education_levels[i] == 'college':
				level = 'Колледж'
			elif education_levels[i] == 'master':
				level = 'Магистратура'
			elif education_levels[i] == 'phd':
				level = 'PhD'
			html = f"""{html}
        <li>
          <div class="eduItem">
            <b style="font-weight: 500">
							{education_unis[i]}, {level}, {education_directions[i]}
						</b><br>
            {education_dates_from[i]} - {education_dates_to[i]}
        </div>
       </li>
      """

		html = f"""{html}
		        </ul>
		      </div>
		      <hr>

		      <!-- LANGUAGES -->

		      <div class="skills">
		        <h2>Владение языками:</h2>
		        <ul>
		    """

		for i in range(len(languages)):
			html = f"""{html}
		        <li>
		          <p>{languages[i]}</p>
		        </li>
		      """
		html = f"""{html}</ul><ul style="list-style: none;">"""

		for i in range(len(language_levels)):
			level = ''
			if language_levels[i] == 'basic':
				level = '30%'
			elif language_levels[i] == 'middle':
				level = '55%'
			elif language_levels[i] == 'pro':
				level = '100%'

			html = f"""{html}
	        <li>
	          <div class="progress">
	            <div class="progress-line" style="width: {level};"></div>
	          </div>
	        </li>
	      """

		html = f"""{html}
							</ul>
					  </div>
					  <hr class="underLangHr">
            <div class="skills">
              <h2>Навыки:</h2>
	            <ul>"""

		for i in range(len(skills)):
			html = f"""{html}
		        <li>
		          <p>{skills[i]}</p>
		        </li>
		      """
		html = f"""{html}</ul><ul style="list-style: none;">"""

		for i in range(len(skill_levels)):
			level = ''
			if skill_levels[i] == 'basic':
				level = '30%'
			elif skill_levels[i] == 'middle':
				level = '55%'
			elif skill_levels[i] == 'pro':
				level = '100%'
			html = f"""{html}
		        <li>
		          <div class="progress">
		            <div class="progress-line" style="width: {level};"></div>
		          </div>
		        </li>
		      """

		html = f"""{html}
              </ul>
	          </div>
	          <hr class="underLangHr">
	          <div class="characteristics">
	            <h2>Характерные качества:</h2>
	            <ul>"""
		for i in range(len(character_skills)):
			html = f"""{html}
		      <li>
		        {character_skills[i]}
		      </li>"""

		html = f"""{html}
              </ul>
					  </div>
					
					  <hr class="underLangHr">
					
					  <div class="certifications">
              <h2>Сертификаты:</h2>
              <ul>"""
		for i in range(len(certifications)):
			html = f"""{html}
                 <li>
                   {certifications[i]}
                 </li>
         """

		html = f"""{html}
                    </ul>
					        </div>
								</div>
							</body>
						</html>"""

		with open(f'cvs/{str(filename).replace(".pdf", ".html")}', 'w', encoding='UTF-8') as f:
			f.write(html)

		HTML(f'cvs/{str(filename).replace(".pdf", ".html")}', encoding='UTF-8').write_pdf(f'cvs/{filename}')

		os.remove(f'cvs/{str(filename).replace(".pdf", ".html")}')
		if photo:
			os.remove(photo)

	elif lang == 'uz':
		html = """
		<html lang="ru-RU"></html>
		<head>
		  <meta charset="utf-8">
		  <title>CV</title>
		  <meta name="app-name" content="embed">
		  <link rel="preconnect" href="https://fonts.googleapis.com">
		  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
		  <link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap"
		        rel="stylesheet">
		  <link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap"
		        rel="stylesheet">
		  <style>
		    :root {
		      --main-block-color: #b29772;
					--main-title-color: #8F754F;
					--main-progress-color: #6d421d;
					--main-blue-color: #DDD;
		    }
		    @page {
		      size: A3;
		      margin: 0;
		      width: 1190px;
		    }
		    * {
			     /* width: 2481px;
			     height: 3507px; */
			     margin: 0;
		    }
		    body {
		      font-family: 'Montserrat';
		    }
		    a {
		      text-decoration: none;
		    }
		    .aside {
		     width: 34%;
		     height: 4960px;
		     background: #222;
		     text-align: center;
		     display: inline-block;
		    }
		    .aside .userPhoto {
		     width: 261px;
		     height: 261px;
		     object-fit: cover;
		     margin-top: 3.5em;
		    }
		    .username {
		     color: var(--main-blue-color);
		     text-transform: uppercase;
		     font-family: 'Montserrat';
		     letter-spacing: 1.2;
		     margin-top: 1.3em;
		    }
		    .main-content {
		     width: 60%;
		     display: inline-block;
		     vertical-align: top; 
		     margin-top: 3.5em;
		     margin-left: 3.5em;
		    }
		    .footTitle {
		     margin-top: 0.4em;
		     font-family: 'Montserrat';
		     font-weight: 500;
		     text-align: left;
		     font-size: 19;
		     margin-left: 2.9em;
		     line-height: 1.5;
		    }
		    .contacts {
		     margin-top: 2em;
		     font-family: 'Montserrat';
		     text-align: left;
		    }
		    .contacts h4 {
		      margin-left: 1.7em;
		      font-weight: 600;
		      color: var(--main-blue-color);
		      font-size: 23;
		    }
		    .contacts li {
		     margin-top: 0.7em;
		     color: black;
		     font-family: 'Montserrat';
		     font-weight: 500;
		     margin-left: 1em;
		     font-size: 19;
		    }
		    .contacts li:first-child{
		     margin-top: 1em;
		    }
		    .contacts a {
		     color: black;
		     font-family: 'Montserrat';
		     font-weight: 500;
		    }
		    .exp h2 {
		     color: var(--main-title-color);
		     font-weight: 600;
		    }
		    .exp ul {
		     margin-top: 1.2em;
		     font-weight: 500;
		     font-size: 18;
		    }
		    .exp ul li {
		     margin-top: 2em;
		    }
		    .exp ul li:first-child {
		     margin-top: 0;
		    }
		    hr {
		      margin-top: 1.3em;
		      width: 92%;
		      border-width: 1.5px;
		      border-color: var(--main-block-color);
		      border-style: solid;
		    }
		    .underLangHr {
		      margin-top: 2.2em;
		    }
		    .exp .workItem {
		     display: block;
		     line-height: 2;
		    }
		    .education {
		     margin-top: 3em;
		    }
		    .education h2 {
		     color: var(--main-title-color);
		     font-weight: 600;
		    }
		    .education ul {
		     margin-top: 1.2em;
		     font-size: 19;
		     font-weight: 500;
		    }
		    .education ul li {
		     margin-top: 2em;
		    }
		    .education ul li:first-child {
		     margin-top: 0;
		    }
		    .education ul hr {
		     margin-top: 2em;
		     width: 92%;
		     border-width: 1.2px;
		     border-color: var(--main-block-color);
		     border-style: solid;
		    }
		    .education .eduItem {
		     max-width: 89%;
		     line-height: 2;
		     display: block;
		     white-space: normal;
		     word-wrap: break-word;
		    }

		    .skills {
		     margin-top: 2em;
		    }
		    .skills h2 {
		     color: var(--main-title-color);
		     font-weight: 600;
		    }
		    .skills ul {
		     font-size: 19;
		     margin-top: 1.2em;
		     display: inline-block;
		    }
		    .skills ul li p{
		     display: inline-block;
		    }
		    .skills ul li {
		     margin-top: 1.5em;
		    }
		    .skills ul li:first-child {
		     margin-top: 0;
		    }
		    .progress {
		     width: 200px;
		     height: 9px;
		     display: inline-block;
		     background: #E1E7ED;
		     position: relative;
		     margin-left: 0.5em;
		     vertical-align: middle;
		    }
		    .progress-line {
		     background: var(--main-progress-color);
		     height: 9px;
		     position: absolute;
		     overflow: hidden;
		    }
		    .watermark {
		      width: 205px;
		      position: absolute;
		      margin-left: auto;
		      left: 81.7%;
		      top: -3.8em;
		    }
		    .certifications {
		      margin-top: 2em;
		      font-size: 17;
		    }
		    .certifications ul {
		     font-size: 19;
		     margin-top: 1.2em;
		    }
		    .certifications h2 {
		      color: var(--main-title-color);
		      font-weight: 600;
		    }
		    .certifications li {
		      margin-top: 1.5em;
		    }
		    .certifications li:first-child {
		      margin-top: 0;
		    }
		    .characteristics {
		      margin-top: 3em;
		      font-size: 17;
		    }
		    .characteristics ul {
		      margin-top: 1.2em;
		      font-size: 19;
		    }
		    .characteristics h2 {
		      color: var(--main-title-color);
		      font-weight: 600;
		    }
		    .characteristics li {
		      margin-top: 1.5em;
		    }
		    .characteristics li:first-child {
		      margin-top: 0;
		    }
		  </style>
		  </head>
			<body>
		    <div class="aside">
		"""
		if photo:
			html = f"""{html}
						<img src="{photo}" alt="avatar" class="userPhoto">
						<h1 class="username">{name} {surname}</h1>
						<h4 class="footTitle">Выпускник {education_unis[0]}<br>"""
		else:
			html = f"""{html}
			<h1 class="username" style="margin-top: 3em;">{name} {surname}</h1>
		  <h4 class="footTitle">Выпускник {education_unis[0]}<br>"""
		html = f"""{html}
		    Возраст {age} лет
		  </h4>
		  <div class="contacts">
		    <h4>Контакты:</h4>
		    <ul style="list-style: none;">
		      <li>
		        <a href="tel:998912545650" class="phone">
		          <p>
		            Тел: {phone}
		          </p>
		        </a>
		      </li>
		      <li>
		        Email: <a href="mailto:cardano@gmail.com">{email}</a>
		      </li>
		    </ul>
		  </div>
		</div>
		<div class="main-content">
		  <img src="wrap.png" class="watermark">

		  <div class="exp">
		    <h2>Опыт работы:</h2>
		    <ul style="list-style: none;">
		"""
		for i in range(len(work_companies)):
			html = f"""{html}
						<li>
				      <p class="workItem">
				        <b style="font-weight: 500;">С {work_dates_from[i]} по {work_dates_to[i]}</b>
				        {work_roles[i]} в компании <i style="font-weight: 400;">{work_companies[i]}</i>
				      </p>
				    </li>"""
		html = f"""{html}
		</ul>
		  </div>
		  <hr>
		  <div class="education">
		    <h2>Образование:</h2>
		    <ul style="list-style: none;">"""
		for i in range(len(education_levels)):
			level = ''
			if education_levels[i] == 'Bachelor':
				level = 'Бакалавр'
			elif education_levels[i] == 'school':
				level = "Среднее образование"
			elif education_levels[i] == 'college':
				level = 'Колледж'
			elif education_levels[i] == 'master':
				level = 'Магистратура'
			elif education_levels[i] == 'phd':
				level = 'PhD'
			html = f"""{html}
						<li>
			        <div class="eduItem">
			          <b style="font-weight: 500">
									{education_unis[i]}, {level}, {education_directions[i]}
								</b><br>
		            {education_dates_from[i]} - {education_dates_to[i]}
			        </div>
		        </li>"""
		html = f"""{html}
						</ul>
				  </div>
				  <hr>

					  <!-- LANGUAGES -->

				  <div class="skills">
				    <h2>Владение языками:</h2>
				    <ul>
				"""
		for i in range(len(languages)):
			html = f"""{html}
						<li>
			        <p>{languages[i]}</p>
			      </li>"""
		html = f"""{html}</ul><ul style="list-style: none;">"""
		for i in range(len(language_levels)):
			level = ''
			if language_levels[i] == 'basic':
				level = '30%'
			elif language_levels[i] == 'middle':
				level = '55%'
			elif language_levels[i] == 'pro':
				level = '100%'
			html = f"""{html}
						<li>
			        <div class="progress">
			          <div class="progress-line" style="width: {level};"></div>
			        </div>
			      </li>"""
		html = f"""{html}
						</ul>
				  </div>
				  <hr class="underLangHr">

				  <div class="skills">
				    <h2>Навыки:</h2>
				    <ul>"""
		for i in range(len(skills)):
			html = f"""{html}
						<li>
			        <p>{skills[i]}</p>
			      </li>"""
		html = f"""{html}</ul><ul style="list-style: none;">"""
		for i in range(len(skill_levels)):
			level = ''
			if skill_levels[i] == 'basic':
				level = '30%'
			elif skill_levels[i] == 'middle':
				level = '55%'
			elif skill_levels[i] == 'pro':
				level = '100%'
			html = f"""{html}
						<li>
			        <div class="progress">
			          <div class="progress-line" style="width: {level};"></div>
			        </div>
			      </li>"""
		html = f"""{html}
						</ul>
				  </div>

				  <hr class="underLangHr">
				  <div class="characteristics">
				    <h2>Характерные качества:</h2>
				    <ul>"""
		for i in range(len(character_skills)):
			html = f"""{html}
						<li>
			        {character_skills[i]}
			      </li>"""
		html = f"""{html}
						</ul>
				  </div>

				  <hr class="underLangHr">
				  <div class="certifications">
				    <h2>Сертификаты:</h2>
						<ul>"""
		for i in range(len(certifications)):
			html = f"""{html}
		      <li>
		        {certifications[i]}
		      </li>"""
		html = f"""{html}
									</ul>
					      </div>
							</div>
						</body>
					</html>"""

		with open(f'cvs/{str(filename).replace(".pdf", ".html")}', 'w', encoding='UTF-8') as f:
			f.write(html)

		HTML(f'cvs/{str(filename).replace(".pdf", ".html")}', encoding='UTF-8').write_pdf(f'cvs/{filename}')

		os.remove(f'cvs/{str(filename).replace(".pdf", ".html")}')
		if photo:
			os.remove(photo)

	elif lang == 'uz':
		html = """
				<html lang="ru-RU"></html>
				<head>
				  <meta charset="utf-8">
				  <title>CV</title>
				  <meta name="app-name" content="embed">
				  <link rel="preconnect" href="https://fonts.googleapis.com">
				  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
				  <link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap"
				        rel="stylesheet">
				  <link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap"
				        rel="stylesheet">
				  <style>
				    :root {
				      --main-block-color: #b29772;
						  --main-title-color: #8F754F;
						  --main-progress-color: #6d421d;
						  --main-blue-color: #DDD;
				    }
				    @page {
				      size: A3;
				      margin: 0;
				      width: 1190px;
				    }
				    * {
					     /* width: 2481px;
					     height: 3507px; */
					     margin: 0;
				    }
				    body {
				      font-family: 'Montserrat';
				    }
				    a {
				      text-decoration: none;
				    }
				    .aside {
				     width: 34%;
				     height: 4960px;
				     background: #89C5D2;
				     text-align: center;
				     display: inline-block;
				    }
				    .aside .userPhoto {
				     width: 261px;
				     height: 261px;
				     object-fit: cover;
				     margin-top: 3.5em;
				    }
				    .username {
				     color: var(--main-blue-color);
				     text-transform: uppercase;
				     font-family: 'Montserrat';
				     letter-spacing: 1.2;
				     margin-top: 1.3em;
				    }
				    .main-content {
				     width: 60%;
				     display: inline-block;
				     vertical-align: top; 
				     margin-top: 3.5em;
				     margin-left: 3.5em;
				    }
				    .footTitle {
				     margin-top: 0.4em;
				     font-family: 'Montserrat';
				     font-weight: 500;
				     text-align: left;
				     margin-left: 2.9em;
				     line-height: 1.5;
				    }
				    .contacts {
				     margin-top: 2em;
				     font-family: 'Montserrat';
				     text-align: left;
				    }
				    .contacts h2 {
				      margin-left: 1.7em;
				      font-weight: 600;
				      color: var(--main-blue-color);
				    }
				    .contacts li {
				     margin-top: 0.7em;
				     color: black;
				     font-family: 'Montserrat';
				     font-weight: 600;
				     font-size: 21px;
				    }
				    .contacts li:first-child{
				     margin-top: 1em;
				    }
				    .contacts a {
				     color: black;
				     font-family: 'Montserrat';
				     font-weight: 600;
				    }
				    .exp h2 {
				     color: var(--main-title-color);
				     font-weight: 600;
				    }
				    .exp ul {
				     margin-top: 1.2em;
				     font-weight: 600;
				    }
				    .exp ul li {
					     margin-top: 2em;
					     font-size: 24px;
				    }
				    .exp ul li:first-child {
				     margin-top: 0;
				    }
				    hr {
				      margin-top: 1.3em;
				      width: 92%;
				      border-width: 1.5px;
				      border-color: var(--main-block-color);
				      border-style: solid;
				    }
				    .underLangHr {
				      margin-top: 2.2em;
				    }
				    .exp .workItem {
				     display: block;
				     line-height: 2;
				    }
				    .education {
				     margin-top: 3em;
				    }
				    .education h2 {
				     color: var(--main-title-color);
				     font-weight: 600;
				    }
				    .education ul {
				     margin-top: 1.2em;
				     font-weight: 600;
				    }
				    .education ul li {
					     font-size: 24px;
					     margin-top: 2em;
				    }
				    .education ul li:first-child {
				     margin-top: 0;
				    }
				    .education ul hr {
				     margin-top: 2em;
				     width: 92%;
				     border-width: 1.2px;
				     border-color: var(--main-block-color);
				     border-style: solid;
				    }
				    .education .eduItem {
				     max-width: 89%;
				     line-height: 2;
				     display: block;
				     white-space: normal;
				     word-wrap: break-word;
				    }
				    .skills {
				     margin-top: 2em;
				    }
				    .skills h2 {
				     color: var(--main-title-color);
				     font-weight: 600;
				    }
				    .skills ul {
				     margin-top: 1.2em;
				     display: inline-block;
				     font-weight: 600;
				    }
				    .skills ul li p{
				     font-size: 24px;
				     display: inline-block;
				    }
				    .skills ul li {
				     margin-top: 1.5em;
				    }
				    .skills ul li:first-child {
				     margin-top: 0;
				    }
				    .progress {
				     width: 200px;
				     height: 9px;
				     display: inline-block;
				     background: #E1E7ED;
				     position: relative;
				     margin-left: 0.5em;
				     vertical-align: middle;
				    }
				    .progress-line {
				     background: var(--main-progress-color);
				     height: 9px;
				     position: absolute;
				     overflow: hidden;
				    }
				    .watermark {
				      width: 205px;
				      position: absolute;
				      margin-left: auto;
				      left: 81.7%;
				      top: -3.8em;
				    }
				    .certifications {
				      margin-top: 2em;
				      font-weight: 600;
				    }
				    .certifications ul {
				     margin-top: 1.2em;
				    }
				    .certifications h2 {
				      color: var(--main-title-color);
				      font-weight: 600;
				    }
				    .certifications li {
				      font-size: 24px;
				      margin-top: 1.5em;
				    }
				    .certifications li:first-child {
				      margin-top: 0;
				    }
				    .characteristics {
				      margin-top: 3em;
				      font-weight: 600;
				    }
				    .characteristics ul {
				      margin-top: 1.2em;
				    }
				    .characteristics h2 {
				      color: var(--main-title-color);
				      font-weight: 600;
				    }
				    .characteristics li {
				      font-size: 24px;
				      margin-top: 1.5em;
				    }
				    .characteristics li:first-child {
				      margin-top: 0;
				    }
				  </style>
				  </head>
					<body>
				    <div class="aside">
				"""
		if photo:
			html = f"""{html}
						<img src="{photo}" alt="avatar" class="userPhoto">
						<h1 class="username">{name} {surname}</h1>
						<h4 class="footTitle">{education_unis[0]} bitiruvchisi<br>"""
		else:
			html = f"""{html}
					<h1 class="username" style="margin-top: 3em;">{name} {surname}</h1>
				  <h4 class="footTitle">{education_unis[0]} bitiruvchisi<br>"""
		html = f"""{html}
				    Yosh: {age}
				  </h4>
				  <div class="contacts">
				    <h2>Kontaktlar:</h2>
				    <ul style="list-style: none;">
				      <li>
				        <a href="tel:998912545650" class="phone">
				          <p>
				            Telefon: {phone}
				          </p>
				        </a>
				      </li>
				      <li>
				        Email: <a href="mailto:cardano@gmail.com">{email}</a>
				      </li>
				    </ul>
				  </div>
				</div>
				<div class="main-content">
				  <img src="wrap.png" class="watermark">

				  <div class="exp">
				    <h2>Ish tajribasi:</h2>
				    <ul style="list-style: none;">
				"""
		for i in range(len(work_companies)):
			html = f"""{html}
								<li>
						      <p class="workItem">
						        <i style="font-weight: 500;">{work_companies[i]}</i>, {work_roles[i]} <br>
						         <b style="font-weight: 500;">{work_dates_from[i]} - {work_dates_to[i]}</b>
						      </p>
						    </li>"""
		html = f"""{html}
				</ul>
				  </div>
				  <hr>
				  <div class="education">
				    <h2>Ta'lim darajasi:</h2>
				    <ul style="list-style: none;">"""
		for i in range(len(education_levels)):
			level = ''
			if education_levels[i] == 'Bachelor':
				level = 'bakalavr'
			elif education_levels[i] == 'school':
				level = "O'rta ta'lim"
			elif education_levels[i] == 'college':
				level = 'Kolledj'
			elif education_levels[i] == 'master':
				level = 'Magistratura'
			elif education_levels[i] == 'phd':
				level = 'PhD'
			html = f"""{html}
								<li>
					        <div class="eduItem">
					          <b style="font-weight: 500">
					            <i style="font-weight: 500;">
												{education_unis[i]}
											</i>, 
											{level}, {education_directions[i]}
										</b>
					          {education_dates_from[i]} - {education_dates_to[i]}
					        </div>
				        </li>"""
		html = f"""{html}
								</ul>
						  </div>
						  <hr>

							  <!-- LANGUAGES -->

						  <div class="skills">
						    <h2>Chet tillari:</h2>
						    <ul>
						"""
		for i in range(len(languages)):
			html = f"""{html}
								<li>
					        <p>{languages[i]}</p>
					      </li>"""
		html = f"""{html}</ul><ul style="list-style: none;">"""
		for i in range(len(language_levels)):
			level = ''
			if language_levels[i] == "basic":
				level = '30%'
			elif language_levels[i] == "middle":
				level = '55%'
			elif language_levels[i] == "pro":
				level = '100%'
			html = f"""{html}
								<li>
					        <div class="progress">
					          <div class="progress-line" style="width: {level};"></div>
					        </div>
					      </li>"""
		html = f"""{html}
								</ul>
						  </div>
						  <hr class="underLangHr">

						  <div class="skills">
						    <h2>Kompyuter savodxonligi:</h2>
						    <ul>"""
		for i in range(len(skills)):
			html = f"""{html}
								<li>
					        <p>{skills[i]}</p>
					      </li>"""
		html = f"""{html}</ul><ul style="list-style: none;">"""
		for i in range(len(skill_levels)):
			level = ''
			if skill_levels[i] == "basic":
				level = '30%'
			elif skill_levels[i] == "middle":
				level = '55%'
			elif skill_levels[i] == "pro":
				level = '100%'
			html = f"""{html}
								<li>
					        <div class="progress">
					          <div class="progress-line" style="width: {level};"></div>
					        </div>
					      </li>"""
		html = f"""{html}
								</ul>
						  </div>

						  <hr class="underLangHr">
						  <div class="characteristics">
						    <h2>Ko'nikmalar:</h2>
						    <ul>"""
		for i in range(len(character_skills)):
			html = f"""{html}
								<li>
					        {character_skills[i]}
					      </li>"""
		html = f"""{html}
								</ul>
						  </div>

						  <hr class="underLangHr">
						  <div class="certifications">
						    <h2>O'quv kurslari, sertifikatlar:</h2>
								<ul>"""
		for i in range(len(certifications)):
			html = f"""{html}
				      <li>
				        {certifications[i]}
				      </li>"""
		html = f"""{html}
											</ul>
							      </div>
									</div>
								</body>
							</html>"""

		with open(f'cvs/{str(filename).replace(".pdf", ".html")}', 'w', encoding='UTF-8') as f:
			f.write(html)

		HTML(f'cvs/{str(filename).replace(".pdf", ".html")}', encoding='UTF-8').write_pdf(f'cvs/{filename}')
		# images = convert_from_path(f'cvs/{filename}')
		# for i in range(len(images)):
		#   images[i].save(f'cvs/{str(filename).replace(".pdf", ".jpg")}', 'JPEG')

		os.remove(f'cvs/{str(filename).replace(".pdf", ".html")}')

		if photo:
			os.remove(photo)

#
# async def main():
# 	await MakePdfBlueHor(
# 			lang='uz',
# 			filename='filename.pdf',
# 			name='Alisher',
# 			surname='Eshqobilov',
# 			email='emailToPass@gmail.com',
# 			phone='+923152904968',
# 			city='Toshkent',
# 			age='30',
# 			work_companies=['Uzunbuloq suv tozalash inshooti'],
# 			work_roles=['Yetakchi mutaxassis'],
# 			work_dates_from=['2021'],
# 			work_dates_to=['2022'],
# 			education_unis=['Jizzax iqtisodiyot instituti', 'Moliya'],
# 			education_levels=['Bakalavr', 'Bakalavr'],
# 			education_directions=['Quruvchi muhandisi', 'Bank Moliya Akademiyasi'],
# 			education_dates_from=['2018', '2022'],
# 			education_dates_to=['2022', '2024'],
# 			certifications=['Quruvchi muhandisi'],
# 			character_skills=["Qat'iyatlik", 'Sabrlilik'],
# 			languages=['Ingliz tili', 'Rus tili'],
# 			language_levels=["O'rtacha", "O'rtacha"],
# 			skills=['MS Office', 'Photoshop'],
# 			skill_levels=["O'rtacha", "Boshlang'ich"],
# 			photo='/Users/macbook/PycharmProjects/Bots/CVMaker/cvs/default-avatar.jpg'
# 		)
#
#
# asyncio.run(main())
