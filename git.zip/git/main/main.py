#!/usr/bin/python3
import datetime

from pyrogram import Client, compose
from pyrogram import filters
from pyrogram.enums import ChatType
from pyrogram.handlers import MessageHandler
from pyrogram.types import CallbackQuery, Message, \
	InlineKeyboardMarkup, InlineKeyboardButton
import asyncio
import re

# import time


api_id = 29874213
api_hash = '0e218589fc539364c07628d1bc10aaa4'
api_token = '6940932357:AAEs5jiLDkfY3SNfdDID9vBUnE8PcNY3PwM'
sent_ids = []

CARSBUGUN = -1002105904314
ISHTOPISH = -1002044959438


async def main():
	bot = Client("mainBot", api_id=api_id, bot_token=api_token, api_hash=api_hash)
	
	@bot.on_callback_query()
	async def answerNumber(bot: Client, query: CallbackQuery):
		if query.data.startswith('vacancyNumber_'):
			try:
				await bot.get_chat_member(ISHTOPISH, query.from_user.id)
			except:
				await bot.answer_callback_query(query.id, 'Telefon raqamini ko\'rish uchun kanalga obuna b\'ling!',
				                                show_alert=True)
			else:
				if (datetime.datetime.now() - query.message.date).days > 15:
					await bot.answer_callback_query(query.id, text='Ushbu e\'lon berilganiga 10 kundan ko\'proq muddat o\'tdi!',
					                                show_alert=True)
				else:
					phoneNumber = query.data.replace('vacancyNumber_', '')
					await bot.answer_callback_query(query.id, phoneNumber, show_alert=True)
		elif query.data.startswith('olxNumber_'):
			try:
				await bot.get_chat_member(CARSBUGUN, query.from_user.id)
			except:
				await bot.answer_callback_query(query.id, 'Telefon raqamini ko\'rish uchun kanalga obuna b\'ling!',
				                                show_alert=True)
			else:
				if (datetime.datetime.now() - query.message.date).days > 3:
					await bot.answer_callback_query(query.id, text='Ushbu e\'lon berilganiga 3 kundan ko\'proq muddat o\'tdi!',
					                                show_alert=True)
				else:
					phoneNumber = query.data.replace('olxNumber_', '')
					await bot.answer_callback_query(query.id, phoneNumber, show_alert=True)
	
	await compose([bot])


asyncio.run(main())
